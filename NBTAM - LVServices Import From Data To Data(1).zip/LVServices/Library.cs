﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LVServices
{
    public static class Library
    {
        public static void WriteLog(string massage)
        {
            using (var file = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\log.txt",true))
            {
                file.WriteLine(DateTime.Now.ToString() + ":" + massage);
            }
        }
        public static void WriteServiceLog(string massage)
        {
            using (var file = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\logService.txt", true))
            {
                file.WriteLine(DateTime.Now.ToString() + ":" + massage);
            }
        }
        
    }
}
