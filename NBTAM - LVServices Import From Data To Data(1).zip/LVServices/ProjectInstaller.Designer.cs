﻿namespace LVServices
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LVServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.LVWindowServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // LVServiceProcessInstaller
            // 
            this.LVServiceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
            this.LVServiceProcessInstaller.Password = null;
            this.LVServiceProcessInstaller.Username = null;
            // 
            // LVWindowServiceInstaller
            // 
            this.LVWindowServiceInstaller.ServiceName = "LVWindowServices";
            this.LVWindowServiceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            this.LVWindowServiceInstaller.AfterInstall += new System.Configuration.Install.InstallEventHandler(this.LVWindowServiceInstaller_AfterInstall);
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.LVServiceProcessInstaller,
            this.LVWindowServiceInstaller});

        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller LVServiceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller LVWindowServiceInstaller;
    }
}