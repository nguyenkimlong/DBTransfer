﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Timers;
using System.Xml;

namespace LVServices
{
    public partial class LVWindowServices : ServiceBase
    {
        Thread tr = null;
        public LVWindowServices()
        {
            
            InitializeComponent();
            tr = new Thread(new ThreadStart(timer_Elapsed));
            
        }

        protected override void OnStart(string[] args)
        {    
            tr.Start();
            Library.WriteServiceLog("service start...");
        }

        void timer_Elapsed()
        {
            
            Call_Import();
        }

        private static void Call_Import()
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + "\\config.xml");

                var Time = doc.GetElementsByTagName("ScheduleTime").Item(0).InnerText;
                //var auto = "";
                //if (doc.GetElementsByTagName("AutoExport") != null && doc.GetElementsByTagName("AutoExport").Count > 0)
                //{
                //    auto = doc.GetElementsByTagName("AutoExport").Item(0).InnerText;
                //}


                //var currentTime = ("00" + DateTime.Now.Hour.ToString()).Substring((("00" + DateTime.Now.Hour.ToString()).Length - 2));
                //currentTime = currentTime + ":" + ("00" + DateTime.Now.Minute.ToString()).Substring((("00" + DateTime.Now.Minute.ToString()).Length - 2));
                var Period = 0;
                if(!int.TryParse(Time,out Period))
                {
                    Period = 720;
                }
                Library.WriteLog("time:" + Period.ToString());
                System.Threading.Thread.Sleep(Period * 60 * 1000);
                try
                {
                    Import();
                }
                catch (Exception exp111)
                {
                    Library.WriteLog(exp111.Message);
                }

                Library.WriteLog("finished");
                Call_Import();
                
            }
            catch (Exception exp)
            {
                Library.WriteLog(exp.Message);
            }

        }
        
        protected override void OnStop()
        {
            tr.Abort();
            Library.WriteServiceLog("off");
        }


        public static void Import()
        {
            var sessionID = Guid.NewGuid();
            XmlDocument doc = new XmlDocument();
            doc.Load(Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + "\\config.xml");
            XmlDocument docProcess = new XmlDocument();
            docProcess.Load(Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location) + "\\configProcess.xml");
            var txtScrServer = doc.GetElementsByTagName("SrcServerName").Item(0).InnerText;
            var txtSrcUserName = doc.GetElementsByTagName("SrcUserName").Item(0).InnerText;
            var txtSrcPassword = doc.GetElementsByTagName("SrcPassword").Item(0).InnerText;
            var txtSrcDatabase = doc.GetElementsByTagName("SrcDatabase").Item(0).InnerText;

            var txtServerName = doc.GetElementsByTagName("ServerName").Item(0).InnerText;
            var txtUserName = doc.GetElementsByTagName("UserName").Item(0).InnerText;
            var txtPassword = doc.GetElementsByTagName("Password").Item(0).InnerText;
            var txtDatebase = doc.GetElementsByTagName("Database").Item(0).InnerText;
            var Overwrite = false;

            if (doc.GetElementsByTagName("Overwrite") != null && doc.GetElementsByTagName("Overwrite").Count > 0 && doc.GetElementsByTagName("Overwrite").Item(0).InnerText == "true")
            {
                Overwrite = true;
            }

            var before = docProcess.GetElementsByTagName("BeforeImport");
            var storeBefore = "";
            if(before.Count>0 && before.Item(0).SelectNodes("ExceStore").Count>0) { 
                storeBefore = before.Item(0).SelectNodes("ExceStore").Item(0).InnerText;
            }

            var after = docProcess.GetElementsByTagName("EndImport");
           
            var TableImport = docProcess.GetElementsByTagName("Table");

            if (!string.IsNullOrEmpty(storeBefore))
            {
                using (SqlConnection descConnection = new SqlConnection("Data Source=" + txtServerName + ";Database=" + txtDatebase + ";User Id=" + txtUserName + ";Password=" + txtPassword + "; pooling=false"))
                {
                    descConnection.Open();
                    Library.WriteLog("Begin ExcuteStore " + storeBefore);
                    var cm = descConnection.CreateCommand();
                    cm.CommandText = "Exec " + storeBefore;
                    cm.ExecuteNonQuery();
                }
            }

            foreach (XmlNode item in TableImport)
            {
                var SrcSQL = item.SelectNodes("SrcSQL").Item(0).InnerText;
                var columnKey = "";

                if (item.SelectNodes("SrcSQL").Item(0).Attributes["ColumnKey"] != null)
                {
                    columnKey = item.SelectNodes("SrcSQL").Item(0).Attributes["ColumnKey"].Value;
                }

                var DestTable = item.SelectNodes("TableDest").Item(0).InnerText;
                Dictionary<string, string> cloumnMap = new Dictionary<string, string>();
                string tableDetail = "";
                string tableMaster = "";

                if (item.SelectNodes("TableDest").Item(0).Attributes["TableDetail"] != null)
                {
                    tableDetail = item.SelectNodes("TableDest").Item(0).Attributes["TableDetail"].Value;
                }

                if (item.SelectNodes("TableDest").Item(0).Attributes["tableMaster"] != null)
                {
                    tableMaster = item.SelectNodes("TableDest").Item(0).Attributes["tableMaster"].Value;
                }


                var cloumns = item.SelectNodes("ColumnMap").Item(0).SelectNodes("Column");
                foreach (XmlNode c in cloumns)
                {
                    cloumnMap.Add(c.Attributes["Src"].Value, c.Attributes["Dest"].Value);
                }

                using (SqlConnection sourceConnection = new SqlConnection("Data Source=" + txtScrServer + ";Database=" + txtSrcDatabase + ";User Id=" + txtSrcUserName + ";Password=" + txtSrcPassword + "; pooling=false"))
                {
                    Library.WriteLog("Reading Source");
                    sourceConnection.Open();
                    var sqlDA = new SqlDataAdapter(SrcSQL, sourceConnection);
                    var ds = new DataSet();
                    sqlDA.Fill(ds);

                    Library.WriteLog("Read Source:" + ds.Tables[0].Rows.Count.ToString() + " Record");

                    using (SqlConnection descConnection = new SqlConnection("Data Source=" + txtServerName + ";Database=" + txtDatebase + ";User Id=" + txtUserName + ";Password=" + txtPassword + "; pooling=false"))
                    {
                        descConnection.Open();
                        Library.WriteLog("Begin import " + DestTable);
                        CopyData(descConnection, DestTable, ds.Tables[0], Overwrite, cloumnMap, tableMaster, tableDetail, columnKey);
                        Library.WriteLog("End import " + DestTable);
                    }
                }
            }

            if (after.Count > 0)
            {
                var updateSource = after.Item(0).SelectNodes("UpdateSource");
                if (updateSource.Count > 0)
                {
                    using (SqlConnection sourceConnection = new SqlConnection("Data Source=" + txtScrServer + ";Database=" + txtSrcDatabase + ";User Id=" + txtSrcUserName + ";Password=" + txtSrcPassword + "; pooling=false"))
                    {
                        sourceConnection.Open();
                        Library.WriteLog("Update Source");
                        foreach (XmlNode item in updateSource.Item(0).SelectNodes("ExceSQLAferImport"))
                        {
                            if (!string.IsNullOrEmpty(item.InnerText))
                            {
                                var cm = sourceConnection.CreateCommand();
                                cm.CommandText = item.InnerText;
                                cm.ExecuteNonQuery();
                            }
                        }
                    }
                }

                var updateDest = after.Item(0).SelectNodes("UpdateDest");
                if (updateDest.Count > 0)
                {
                    using (SqlConnection sourceConnection = new SqlConnection("Data Source=" + txtServerName + ";Database=" + txtDatebase + ";User Id=" + txtUserName + ";Password=" + txtPassword + "; pooling=false"))
                    {
                        sourceConnection.Open();
                        Library.WriteLog("Update Dest");
                        foreach (XmlNode item in updateDest.Item(0).SelectNodes("ExceSQLAferImport"))
                        {
                            if (!string.IsNullOrEmpty(item.InnerText))
                            {
                                var commtext = item.InnerText;
                                commtext = commtext.Replace("@SessionID", sessionID.ToString());
                                var cm = sourceConnection.CreateCommand();
                                cm.CommandText = commtext;
                                cm.ExecuteNonQuery();
                            }
                        }
                    }
                }

                var exportCSV = after.Item(0).SelectNodes("ExportCSV");
                if (exportCSV.Count > 0)
                {
                    using (SqlConnection destConnection = new SqlConnection("Data Source=" + txtServerName + ";Database=" + txtDatebase + ";User Id=" + txtUserName + ";Password=" + txtPassword + "; pooling=false"))
                    {
                        destConnection.Open();
                        Library.WriteLog("Export CSV");
                        
                        if (!string.IsNullOrEmpty(exportCSV.Item(0).InnerText))
                        {
                            var commtext = exportCSV.Item(0).InnerText;
                            commtext = commtext.Replace("@SessionID", sessionID.ToString());
                            DataSet ds = new DataSet();
                            System.Data.SqlClient.SqlDataAdapter da = new System.Data.SqlClient.SqlDataAdapter(commtext, destConnection);
                            da.Fill(ds);

                            var file_Name = "Import";

                            file_Name = file_Name + DateTime.Now.Year.ToString() + ("00" + DateTime.Now.Month.ToString()).Substring((("00" + DateTime.Now.Month.ToString()).Length - 2)) + ("00" + DateTime.Now.Day.ToString()).Substring((("00" + DateTime.Now.Day.ToString()).Length - 2)) + " " + ("00" + DateTime.Now.Hour.ToString()).Substring((("00" + DateTime.Now.Hour.ToString()).Length - 2)) + ("00" + DateTime.Now.Minute.ToString()).Substring((("00" + DateTime.Now.Minute.ToString()).Length - 2));

                            file_Name = file_Name + ".csv";

                            if(!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "\\logs"))
                            {
                                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "\\logs");
                            }

                            using (var file = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "\\logs\\" + file_Name, false))
                            {
                                WriteDataTable(ds.Tables[0], file, true);
                            }
                            
                        }
                    }
                }
            }
        }
        public static void CopyData(SqlConnection conn, string tablename, DataTable dt, bool overwrite, Dictionary<string, string> cloumnMap, string tableMaster, string tableDetail, string ColumnKey)
        {
            var tran = conn.BeginTransaction();
            try
            {

                SqlCommand cmd1 = new SqlCommand();
                cmd1.CommandType = CommandType.Text;
                cmd1.Connection = conn;
                cmd1.Transaction = tran;

                string table = "";
                table += "IF OBJECT_ID('tempdb..#zzzlvimport" + tablename + "') IS NOT NULL ";
                table += "BEGIN ";
                table += "DROP TABLE #zzzlvimport" + tablename + " ";
                table += "END ";
                table += "SELECT TOP 0 * INTO #zzzlvimport" + tablename + " FROM " + tablename + " ";

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = table;
                cmd.Connection = conn;
                cmd.Transaction = tran;
                cmd.ExecuteNonQuery();


                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(conn, SqlBulkCopyOptions.KeepIdentity | SqlBulkCopyOptions.KeepNulls, tran))
                {

                    bulkCopy.DestinationTableName = "#zzzlvimport" + tablename;

                    foreach (var item in cloumnMap)
                    {
                        bulkCopy.ColumnMappings.Add(item.Key, item.Value);
                    }

                    bulkCopy.WriteToServer(dt);
                    bulkCopy.Close();
                }

                var insertString = InsertString(cloumnMap)[0];
                var insertStringAlias = InsertString(cloumnMap)[1];
                var keyCol = ColumnKey;
                if (string.IsNullOrEmpty(keyCol)) keyCol = "DocumentID";

                if (overwrite)
                {
                    if (!string.IsNullOrEmpty(tableDetail))
                    {
                        cmd1.CommandText = "DELETE M FROM #zzzlvimport" + tablename + " T INNER JOIN " + tableDetail + " M ON T."+ keyCol + "= M." + keyCol + " \r\n";
                        cmd1.ExecuteNonQuery();
                    }

                    cmd1.CommandText = "DELETE M FROM #zzzlvimport" + tablename + " T INNER JOIN " + tablename + " M ON T." + keyCol + "= M." + keyCol + " \r\n";
                    cmd1.ExecuteNonQuery();

                    cmd1.CommandText = "INSERT INTO " + tablename + "(" + insertString + ") SELECT " + insertStringAlias + " FROM #zzzlvimport" + tablename + " T ";
                }
                else
                {
                    cmd1.CommandText = "INSERT INTO " + tablename + "(" + insertString + ") SELECT " + insertStringAlias + " FROM #zzzlvimport" + tablename + " T LEFT JOIN " + tablename + " M ON T." + keyCol + "= M." + keyCol + " WHERE M." + keyCol + " IS NULL";
                }

                cmd1.ExecuteNonQuery();
                tran.Commit();
            }
            catch (Exception exp)
            {
                tran.Rollback();
                throw exp;
            }

        }

        private static string[] InsertString(Dictionary<string, string> cloumnMap)
        {
            string dest = "";
            string destalias = "";
            foreach (var item in cloumnMap)
            {
                if (!string.IsNullOrEmpty(destalias)) destalias = destalias + ",";
                destalias = destalias + "T." + item.Value;

                if (!string.IsNullOrEmpty(dest)) dest = dest + ",";
                dest = dest + item.Value;
            }

            return new string[] { dest, destalias };
        }

        public static void WriteDataTable(DataTable sourceTable, TextWriter writer, bool includeHeaders)
        {

            if (includeHeaders)
            {
                List<string> headerValues = new List<string>();
                foreach (DataColumn column in sourceTable.Columns)
                {
                    headerValues.Add(column.ColumnName);
                }

                writer.WriteLine(String.Join("\t", headerValues.ToArray()));
            }
            
           
            string[] items = null;
            foreach (DataRow row in sourceTable.Rows)
            {
                items = row.ItemArray.Select(o => o==null ? "" : o.ToString()).ToArray();
                List<string> ls = new List<string>();
                foreach (var item in items)
                {
                    if (item != null)
                    {
                        ls.Add(item.Replace("\r", " ").Replace("\n", " ").Replace("\t", " "));
                    }
                }

                writer.WriteLine(String.Join("\t", ls.ToArray()));
            }

            writer.Flush();
        }

    }
}
