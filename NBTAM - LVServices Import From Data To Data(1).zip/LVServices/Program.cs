﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Windows.Forms;

namespace LVServices
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                //Application.EnableVisualStyles();
                //Application.SetCompatibleTextRenderingDefault(false);
                //Application.Run(new Form1());

                ServiceBase.Run(new LVWindowServices());
            }
            catch (Exception e)
            {
                Console.WriteLine("Generic Exception Handler: {0}",
      e.ToString());
            } 

            
        }
    }
}
